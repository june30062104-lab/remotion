# Những lựa chọn nhỏ — bản mẫu 62,3 giây

Remotion 4.0.538 · 1920×1080 · 30 fps · 1.869 frame.

## Tình trạng
Bản MP4 hiện là bản hình **chưa có âm thanh**. MP3 được cung cấp vượt giới hạn tải 32 MiB của công cụ, nên chưa thể nghe, đo loudness hoặc kiểm tra đồng bộ tiếng. SRT là nguồn thời gian, không được coi là dữ kiện đã kiểm chứng độc lập. Các nhân vật là minh họa giản lược, không phải chân dung chính xác. Hình tham chiếu được dùng làm gợi ý trang phục; không nhúng ảnh gốc hoặc giả lập chuyển động tay chân từ ảnh đó.

## Chạy
```
npm ci
npm run dev -- src/index.tsx --port=3100
npm run render
```
Lệnh render dùng /usr/bin/chromium; đổi đường dẫn nếu máy khác. Không cần repository monorepo hay credential.

## Ghép giọng gốc
Đặt đoạn âm thanh bắt đầu từ 00:00 của bản gốc vào `public/voice.mp3`, giữ nguyên tốc độ. Đoạn mẫu dùng 00:00–01:02,300, kết thúc sau câu “Mà chỉ để suy nghĩ”. Đổi `voiceover` thành `true` trong defaultProps ở `src/index.tsx`, kiểm tra phát và sync rồi render lại. Không dùng bản MP4 hình để kết luận sync âm thanh đã đạt.

## Hình ảnh
Nhân vật đầu tròn sáng, nét xanh đen, bối cảnh vector nhiều lớp, bảng màu giấy ngà / xanh xám / vàng đất. Cắt theo thay đổi ý, xe di chuyển độc lập với thành phố; sơ đồ đường đi được vẽ dần. Phụ đề nhỏ từ SRT, tối đa hai dòng ở các khung đã kiểm tra. `src/captions.json` giữ định dạng Caption.
