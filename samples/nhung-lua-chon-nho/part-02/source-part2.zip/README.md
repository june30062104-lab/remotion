# Những lựa chọn nhỏ — phần 02

Nối tiếp phần 01, lấy nguyên voice từ 01:02,300 đến 02:05,300 của file 1.MP3. Thời lượng phần 02: 63 giây, 1.890 frame, 1920×1080, 30 fps. Giữ nguyên tốc độ voice, chuẩn hóa âm lượng. SRT được cắt và dịch mốc về 0, không viết lại lời thoại.

## Chạy
```
npm ci
npm run dev:part2
npm run render:part2
```
Mặc định Chromium: /usr/bin/chromium; chỉnh đường dẫn nếu máy khác. Entry: src/part2.tsx. Các asset cần thiết được đóng gói trong public/.

## Hình và dựng
12 cảnh hoạt hình có đầy đủ nhân vật, trang phục, đổ bóng và bối cảnh đời thực. Hình tạo bằng AI, có tính minh họa, không phải hình quay thực hay chân dung chính xác. Dùng pan, push-in, pull-out và giữ khung; thêm nhãn độc lập về thời gian, sự chú ý, năng lượng. Không giả lập khẩu hình hoặc chuyển động tay chân bằng ảnh phẳng.

Mỗi ô của public/storyboard-part2.png là một cảnh, được cắt trong Remotion bằng CSS. Chất lượng ảnh từng ô thấp hơn kích thước xuất và được phóng lên. Phụ đề/nhãn là lớp đồ họa riêng. Source JSON theo định dạng Caption.

Đã đối chiếu các khoảng ngắt âm thanh với SRT, không nghe/phiên âm kiểm chứng từng từ. Các dữ kiện và nhận định trong lời thoại đến từ tài liệu người dùng, chưa được xác minh độc lập. Đoạn cuối kết thúc trong khoảng lặng sau câu nói; không nối thêm câu tiếp theo.
