import React from 'react';
import {AbsoluteFill,Audio,Composition,Img,Sequence,interpolate,registerRoot,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import captions from './captions-part2.json';
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
function Scene({panel,title,mode='in'}:{panel:number;title:string;mode?:string}){
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 return <AbsoluteFill style={{overflow:'hidden',background:'#172632',fontFamily:'DejaVu Sans,sans-serif'}}>
 <AbsoluteFill style={{scale:interpolate(frame,[0,8*fps],mode==='hold'?[1.04,1.04]:mode==='out'?[1.12,1.04]:[1.04,1.10],clamp),translate:`${interpolate(frame,[0,8*fps],mode==='pan'?[-20,20]:[0,0],clamp)}px 0`}}>
 <Img src={staticFile('storyboard-part2.png')} style={{position:'absolute',width:'400%',height:'300%',maxWidth:'none',left:`${-(panel%4)*100}%`,top:`${-Math.floor(panel/4)*100}%`}}/>
 </AbsoluteFill>
 <AbsoluteFill style={{background:'linear-gradient(180deg,#0c161fb8 0%,#0c161f22 24%,transparent 40%,transparent 68%,#0c161fc9 100%)'}}/>
 <div style={{position:'absolute',left:90,top:54,color:'#f6d28b',fontSize:21,letterSpacing:5}}>NHỮNG LỰA CHỌN NHỎ</div>
 <div style={{position:'absolute',right:90,top:57,color:'white',fontSize:20}}>PHẦN 02 / GÓC NHÌN</div>
 <div style={{position:'absolute',left:90,top:100,color:'white',fontSize:48,fontWeight:700,textShadow:'0 2px 8px #0006',opacity:interpolate(frame,[0,10],[0,1],clamp)}}>{title}</div>
 {panel===5&&<div style={{position:'absolute',left:100,right:100,bottom:200,display:'flex',gap:22}}>{['THỜI GIAN','SỰ CHÚ Ý','NĂNG LƯỢNG'].map((text,i)=><div key={text} style={{background:'#172632d9',color:'white',borderTop:'4px solid #e5b456',padding:'24px 36px',fontSize:34,opacity:interpolate(frame,[(i*1.6)*fps,(i*1.6+.35)*fps],[0,1],clamp)}}>{text}</div>)}</div>}
 {panel===11&&<div style={{position:'absolute',left:90,bottom:200,color:'#fff',fontSize:37,background:'#172632d9',padding:'20px 30px',borderLeft:'6px solid #e5b456'}}>{frame<5.844*fps?'20 THÓI QUEN ĐỜI THƯỜNG':frame<7.546*fps?'CÓ ĐIỀU RẤT ĐƠN GIẢN':frame<9.415*fps?'CÓ ĐIỀU KHÁ KỲ QUẶC':'HỌC HỎI CÓ CHỌN LỌC'}</div>}
 </AbsoluteFill>
}
function PartTwo(){const frame=useCurrentFrame();const {fps}=useVideoConfig();const c=captions.find(c=>frame/fps*1000>=c.startMs&&frame/fps*1000<c.endMs);return <AbsoluteFill>
<Sequence from={0} durationInFrames={78} premountFor={fps}><Scene panel={0} title="Nghe có vẻ vô lý?" mode="out"/></Sequence>
<Sequence from={78} durationInFrames={131} premountFor={fps}><Scene panel={1} title="Giàu có · Bữa sáng bình dân" mode="in"/></Sequence>
<Sequence from={209} durationInFrames={124} premountFor={fps}><Scene panel={2} title="Điều hành đế chế · Ưu tiên giấc ngủ" mode="hold"/></Sequence>
<Sequence from={333} durationInFrames={146} premountFor={fps}><Scene panel={3} title="Đi làm gần · Lại chọn đường vòng" mode="pan"/></Sequence>
<Sequence from={479} durationInFrames={162} premountFor={fps}><Scene panel={4} title="Nhìn kỹ hơn vào những lựa chọn" mode="in"/></Sequence>
<Sequence from={641} durationInFrames={234} premountFor={fps}><Scene panel={5} title="Không chỉ là có bao nhiêu tiền" mode="hold"/></Sequence>
<Sequence from={875} durationInFrames={227} premountFor={fps}><Scene panel={6} title="Chúng ta thường nhìn vào tài sản" mode="out"/></Sequence>
<Sequence from={1102} durationInFrames={135} premountFor={fps}><Scene panel={7} title="Còn những việc nhỏ mỗi ngày?" mode="pan"/></Sequence>
<Sequence from={1237} durationInFrames={39} premountFor={fps}><Scene panel={8} title="Họ đọc gì khi thức dậy?" mode="in"/></Sequence>
<Sequence from={1276} durationInFrames={123} premountFor={fps}><Scene panel={9} title="Ý tưởng và khoảng thời gian rảnh" mode="pan"/></Sequence>
<Sequence from={1399} durationInFrames={135} premountFor={fps}><Scene panel={10} title="Điều gì thực sự đáng quan tâm?" mode="out"/></Sequence>
<Sequence from={1534} durationInFrames={356} premountFor={fps}><Scene panel={11} title="Khám phá những thói quen đời thường" mode="hold"/></Sequence>
<Audio src={staticFile('voice-part2.m4a')}/>
<div style={{position:'absolute',bottom:43,left:150,right:150,textAlign:'center',fontFamily:'DejaVu Sans,sans-serif',fontSize:32,lineHeight:1.5,color:'white'}}>{c&&<span style={{background:'#172632db',padding:'10px 22px',boxDecorationBreak:'clone'}}>{c.text}</span>}</div>
<div style={{position:'absolute',bottom:0,left:0,height:6,width:`${frame/1890*100}%`,background:'#dd9d38'}}/>
</AbsoluteFill>}
registerRoot(()=><Composition id="HabitsPartTwo" component={PartTwo} width={1920} height={1080} fps={30} durationInFrames={1890}/>);
