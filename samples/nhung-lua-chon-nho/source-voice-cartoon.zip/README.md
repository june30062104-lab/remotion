# Những lựa chọn nhỏ — bản mẫu có voice

62,3 giây · 1920×1080 · 30 fps · H.264 + AAC.

## Chạy
```
npm ci
npm run dev -- src/index.tsx
npm run render
```
Lệnh render dùng Chromium tại /usr/bin/chromium. Chỉnh đường dẫn nếu chạy trên máy khác.

## Nội dung
12 cảnh hoạt hình màu có đầy đủ nhân vật, trang phục, ánh sáng, bối cảnh kiến trúc và nội thất. Hình được tạo bằng AI theo phong cách ảnh tham chiếu; đây là minh họa, không phải hình quay thực hay chân dung chính xác. Các cảnh dùng pan/zoom và chuyển cỡ cảnh; không có animation khẩu hình, tay chân hoặc parallax từ ảnh phẳng.

Voice là 62,3 giây đầu của file 1.MP3 do người dùng cung cấp, giữ nguyên tốc độ, chuẩn hóa loudness. File public/voice.m4a đã sẵn sàng, voiceover=true mặc định. Phụ đề từ SRT cung cấp. Các khoảng dừng của audio trùng mốc kết câu SRT, câu cuối dừng tại khoảng 62,274 giây. Đã đối chiếu tín hiệu và mốc thời gian, chưa nghe kiểm chứng ngữ nghĩa từng từ bằng công cụ nghe/phiên âm.

Loudness đo trong bước chuẩn hóa: khoảng -16,14 LUFS integrated, true peak -1,00 dBTP trước mã hóa AAC. Không tự thêm nhạc hay hiệu ứng để giữ voice rõ. Nội dung theo kịch bản người dùng, chưa kiểm chứng dữ kiện độc lập.

public/cinematic-storyboard.png là một tấm hình 12 ô. Mỗi cảnh cắt một ô bằng CSS trong Remotion; không cần công cụ tạo ảnh để chạy lại. Hình nguồn từng ô có độ phân giải thấp hơn 1080p và được phóng lên trong bản xuất. Chữ/phụ đề là các lớp riêng. src/captions.json dùng định dạng Caption.
