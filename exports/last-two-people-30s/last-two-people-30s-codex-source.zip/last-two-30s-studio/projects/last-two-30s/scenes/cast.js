export const A={top:'hoodie',color:'#d85c3e',head:'ponytail'};
export const B={top:'tshirt',color:'#407ba0',head:'cap',headColor:'#f2c54c'};
