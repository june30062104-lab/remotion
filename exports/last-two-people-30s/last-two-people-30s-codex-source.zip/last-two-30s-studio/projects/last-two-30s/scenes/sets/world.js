import {E,S,mood,shade,alpha,layer,linGrad,glow,rr,seg,poly,circle,ring,text} from '/engine/core.js';
import {drawFigure,POSES,breathe} from '/engine/rig2d.js';
import * as FX from '/engine/fx2d.js';
import {A,B} from '../cast.js';
export function city(g,t,cam={},o={}){
 const M=mood(o.warm?'dusk':'interiorCool');
 g.fillStyle=linGrad(g,0,0,0,E.H,M.sky);g.fillRect(-E.W,-E.H,E.W*3,E.H*3);
 layer(g,cam,.2,()=>{glow(g,1420,320,240,M.key,.22);for(let i=0;i<25;i++){const h=100+(i*113)%340;g.fillStyle=shade(M.wall,-.12);g.fillRect(-80+i*90,750-h,78,h);for(let j=0;j<6;j++){g.fillStyle=alpha(M.practical,.22);g.fillRect(-62+i*90,770-h+j*43,8,15);}}});
 layer(g,cam,.6,()=>{for(const [x,w,h] of [[-80,510,620],[1440,570,680]]){g.fillStyle=M.wall;g.fillRect(x,170,w,h);g.fillStyle=shade(M.wall,.08);g.fillRect(x+10,160,w-20,22);for(let i=0;i<4;i++)for(let j=0;j<3;j++){const xx=x+40+i*115,yy=220+j*165;g.fillStyle=shade(M.dark,.1);g.fillRect(xx,yy,70,110);g.fillStyle=alpha(M.key,.18);g.fillRect(xx+5,yy+5,58,85);g.fillStyle=M.dark;g.fillRect(xx+32,yy,5,100);}}
 g.fillStyle=M.dark;g.fillRect(-100,790,2120,400);poly(g,[[700,730],[1220,730],[1820,1200],[100,1200]],shade(M.road,.06));seg(g,[[700,730],[120,1180]],6,alpha(M.key,.14));seg(g,[[1220,730],[1800,1180]],6,alpha(M.key,.14));for(let i=0;i<6;i++){const y=765+i*i*13,w=8+i*7;g.fillStyle=alpha(M.practical,.35);g.fillRect(960-w/2,y,w,8+i*3);}
 FX.lampPost(g,480,835,360,{color:M.dark,light:M.practical,a:.1});FX.lampPost(g,1390,835,360,{color:M.dark,light:M.practical,a:.1});});
 if(o.car!==false)layer(g,cam,1,()=>car(g,150,875,.9,M));
 FX.dust(g,t,{count:30,color:M.key,a:.13,speed:5});return M;
}
export function car(g,x,y,s,M=mood('interiorWarm')){g.save();g.translate(x,y);g.scale(s,s);g.fillStyle=shade(M.wall,.2);rr(g,-140,-70,280,70,18);g.fill();poly(g,[[-90,-70],[-55,-125],[55,-125],[110,-70]],M.wall);poly(g,[[-75,-75],[-45,-113],[43,-113],[84,-75]],M.sky[0]);circle(g,-85,5,28,M.dark);circle(g,85,5,28,M.dark);circle(g,-85,5,12,M.ambient);circle(g,85,5,12,M.ambient);g.fillStyle=M.practical;g.fillRect(120,-45,20,15);g.restore();}
export function bedroom(g,t,cam={}){
 const M=mood('interiorWarm');g.fillStyle=M.wall;g.fillRect(-E.W,-E.H,E.W*3,E.H*3);
 layer(g,cam,.35,()=>{g.fillStyle=linGrad(g,0,150,0,700,M.sky);g.fillRect(1000,125,700,550);glow(g,1410,420,240,M.key,.35);for(let i=0;i<8;i++){const h=90+(i*67)%160;g.fillStyle=M.dark;g.fillRect(1010+i*85,675-h,70,h);}g.fillStyle=M.dark;g.fillRect(1335,120,15,560);g.fillRect(990,375,720,15);});
 layer(g,cam,.7,()=>{g.fillStyle=M.floor;g.fillRect(-200,820,2320,500);g.fillStyle=shade(M.wall,-.2);g.fillRect(180,470,760,350);g.fillStyle=shade(M.key,-.5);rr(g,160,700,840,130,20);g.fill();g.fillStyle=shade(M.sky[1],.1);rr(g,190,655,750,80,22);g.fill();g.fillStyle=M.key;rr(g,200,620,180,56,20);g.fill();g.fillStyle=M.dark;g.fillRect(170,830,30,110);g.fillRect(940,830,30,110);g.fillRect(1080,735,240,45);g.fillRect(1110,780,20,140);g.fillRect(1270,780,20,140);
 g.fillStyle=shade(M.dark,.12);rr(g,1120,650,160,75,12);g.fill();text(g,'07:00',1200,686,{size:44,color:M.key,font:'Nunito',weight:900});});
 FX.dust(g,t,{count:30,color:M.key,a:.2});return M;
}
export function people(g,t,{x=720,y=855,s=1.8,both=false,pose='stand',expr='worried',talk=0,who='a',alpha:op=1}={}){
 const M=mood('interiorWarm');const of=who==='a'?A:B;drawFigure(g,{x,y,s,outfit:of,pose:breathe(POSES[pose]||POSES.stand,t,1,who==='a'?2:7),facing:who==='a'?1:-1,expr,talk,blink:(t%3.7)>3.55,alpha:op,rim:{color:M.rim,dir:[1,-.5],w:5}});
 if(both)drawFigure(g,{x:x+460,y,s,outfit:B,pose:breathe(POSES.shrug,t,1,7),facing:-1,expr:'confused',rim:{color:M.rim,dir:[-1,-.5],w:5},alpha:op});
}
export function globe(g,x,y,r,t=0){
 const ui=S().ui;glow(g,x,y,r*1.35,ui.blueprint,.28);circle(g,x,y,r,'#253b60');g.save();g.beginPath();g.arc(x,y,r,0,Math.PI*2);g.clip();
 const shapes=[[[.05,-.9],[.38,-.8],[.55,-.5],[.24,-.25],[.42,.05],[.28,.45],[.03,.7],[-.18,.1],[-.4,-.02],[-.5,-.32],[-.2,-.6]],[[-.95,-.45],[-.6,-.65],[-.42,-.4],[-.56,-.1],[-.35,.08],[-.5,.48],[-.7,.7],[-.8,.22]],[[.6,.4],[.92,.36],[1,.7],[.7,.72]]];
 for(const pts of shapes)poly(g,pts.map(([a,b])=>[x+a*r+Math.sin(t*.15)*r*.05,y+b*r]),'#60827c');
 for(let j=-2;j<=2;j++){g.strokeStyle=alpha(ui.blueprint,.13);g.lineWidth=2;g.beginPath();g.ellipse(x,y+j*r*.27,r,Math.max(10,r*.2),0,0,Math.PI*2);g.stroke();}g.restore();ring(g,x,y,r,3,alpha(ui.blueprint,.65));}
