from pathlib import Path
import json,subprocess
import numpy as np
from scipy.io import wavfile
P=Path(__file__).resolve().parent
lines=json.loads((P/'input/lines.json').read_text());shots=[];words=[];offset=.16;rate=1.04;audio=[np.zeros((round(offset*48000),2),np.float32)]
layouts=[ [('wake',.4),('alarm_hand',.66),('window_ots',1)], [('empty_street',.38),('knock',.7),('crossing',1)], [('a_question',1)], [('b_ots',.7),('handshake',1)], [('two_shot',.18),('globe_drop',.5),('low_angle',.72),('pressure_reaction',1)], [('table_top',1)], [('family_pieces',.55),('chaos',1)], [('paper_unroll',.65),('end_action',1)]]
sfx={'wake':('swish',.3,-18),'alarm_hand':('pop',.38,-11),'window_ots':('swish',.14,-16),'empty_street':('footstep',.3,-20),'knock':('hit',.2,-15),'crossing':('swish',.4,-13),'a_question':('pop',.05,-18),'b_ots':('blip',.08,-20),'handshake':('pop',.28,-15),'two_shot':('tick',.1,-21),'globe_drop':('impact',.7,-15),'low_angle':('swish',.05,-19),'pressure_reaction':('pop',.08,-19),'table_top':('paper.wav',.1,-13),'family_pieces':('pop',.3,-16),'chaos':('footstep',.2,-19),'paper_unroll':('paper.wav',.12,-10),'end_action':('whoosh',.1,-17)}
for n,line in enumerate(lines):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(P/f'input/voice-assets/{n:02d}.mp3'),'-af',f'atempo={rate}','-f','f32le','-ac','2','-ar','48000','-']);a=np.frombuffer(raw,dtype=np.float32).reshape(-1,2).copy();duration=len(a)/48000;audio.extend([a,np.zeros((round(line['pause']*48000),2),np.float32)])
 for w in json.loads((P/f'input/voice-assets/{n:02d}.words.json').read_text()):words.append({'word':w['word'],'start':round(offset+w['start']/rate,3),'end':round(offset+w['end']/rate,3),'segment':n})
 start=shots[-1]['end'] if shots else 0;end=offset+duration+line['pause'];speech0=offset
 for name,fraction in layouts[n]:
  b=end if fraction==1 else speech0+duration*fraction
  nm,at,gain=sfx[name]
  shot={'id':name,'start':round(start,4),'end':round(b,4),'line':line['text'],'scene':name,'captions':False,'bars':'wide','in':{'type':'cut'},'sfx':[{'name':nm,'at':min(at,(b-start)*.55),'gain':gain}]}
  if name=='knock':shot['sfx']+=[{'name':'hit','at':min(.5,(b-start)*.7),'gain':-17}]
  shots.append(shot);start=b
 offset=end
assert offset<30,offset
shots[-1]['end']=30
sound=np.concatenate(audio);sound=np.pad(sound,((0,max(0,1440000-len(sound))),(0,0)))[:1440000];wavfile.write(P/'input/voice.wav',48000,sound)
(P/'timeline/words.json').write_text(json.dumps({'words':words,'source':'Edge TTS boundaries scaled by 1.04; no on-screen subtitles'},ensure_ascii=False,indent=2))
(P/'story/shots.json').write_text(json.dumps({'duration':30,'shots':shots,'music':[{'start':0,'end':30,'mood':'playful','intensity':.75}]},ensure_ascii=False,indent=2))
cfg={'title':'Neu-chi-con-hai-nguoi-30s','lang':'vi','aspect':'16:9','resolution':'1080p','fps':24,'style':'dusk','voiceover':'input/voice.wav','duration':30,'captions':False,'bars':'wide','fadeIn':.18,'fadeOut':.35,'music':{'enabled':True,'file':'input/upbeat.wav','gainDb':-16},'sfx':{'enabled':True,'gainDb':-8},'loudness':-16}
(P/'config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
(P/'story/bible.md').write_text('''# Bản dựng 30 giây vui tươi
Tham chiếu: video1030(1).mp4 do người dùng gửi, quan sát toàn cảnh quán phố, macro bàn tay/cốc, góc qua vai, top-down và ánh sáng tím–vàng có chiều sâu. Dựng mới câu chuyện hai người cuối cùng, không chép tình huống bắt ruồi trong mẫu.
User override: rút gọn lời kể để vừa30giây, không phụ đề, chỉ chữ trên đồng hồ và tờ kế hoạch; tập trung diễn xuất, camera và hành động vật lý. Toàn cảnh → macro →OTS →tracking →top-down →hai người phản ứng. Không dùng title card hay biểu đồ toàn màn hình.
A:hoodie cam/tóc đuôi ngựa;B:áo xanh/mũ vàng. Các động tác: vươn vai,tắt đồng hồ,kéo rèm,gõ cửa,đi bộ/chạy khựng lại,bắt tay,nhún vai,gánh địa cầu,cúi gối,trẻ chạy vòng quanh,cuộn giấy dài,truyền quả địa cầu. Giữ viền sáng, ánh sáng vàng và bối cảnh sâu, foreground mờ.
Voice: giọng nam/nữ Microsoft Edge TTS,rate+18%,pitch+12Hz, tăng tốc bổ sung1.04x để khớp30giây. Nhạc tự tổng hợp vui112BPM,pluck/bass/handclap/bell,duck dưới voice. SFX chạm tay,gõ cửa,giấy và chuyển động. Không có nội dung subtitle track hoặc caption overlay.
''')
print(json.dumps({'seconds':30,'shots':len(shots),'frames':720,'speech_end_with_pauses':offset,'captions':False}))
