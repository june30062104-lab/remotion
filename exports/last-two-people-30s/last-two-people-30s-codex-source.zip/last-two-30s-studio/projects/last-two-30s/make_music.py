from pathlib import Path
import sys
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parents[1]/'audio'))
import music
from dsp import write_wav
music.MOODS['playful']['bpm']=124
music.MOODS['playful']['bright']=.72
track=music.render_score([{'start':0,'end':30,'mood':'playful','intensity':.8}],30,seed=70)
write_wav(str(P/'input/upbeat.wav'),track)
print('Created original upbeat 124 BPM music')
