---
name: thanhhai-2d-video
description: Dựng video hoạt hình 2D có voice, phụ đề, camera, nhạc và SFX bằng Canvas, Three.js và FFmpeg trong Codex.
---

Use the studio at the project root (render.mjs, engine/, tools/, audio/).
Read AGENTS.md and references/style-bible.md, story-breakdown.md, engine-api.md, sound-design.md, render-qc.md as needed.
The bundled engine is already in this repository; do not search for a Claude plugin or copy another kit.

1. Infer video language from the user and assets; ask only when unclear. Preserve narration exactly.
2. Defaults: Vietnamese when requested in Vietnamese, 16:9,1080p,24fps,dusk. Reuse supplied SRT; word times imported from SRT are estimates.
3. Run npm ci, select CHROMIUM_PATH or install Playwright Chromium, and install Python requirements in a venv. Whisper is optional when an SRT exists.
4. Create project with tools/new_project.py; import script with tools/parse_script.py or transcribe with tools/transcribe.py.
5. Write story/bible.md, story/shots.json, cast, sets and shot JavaScript. Timeline must be continuous. Examples teach APIs, not universal visuals.
6. Render a contact sheet, inspect it, then preview a short range. Work within authorized scope without repeated approval questions.
7. Render final, run audio/mix.py, then tools/validate_output.py. Deliver actual MP4 and editable source; clearly report untested paths and source attribution.

Never claim a runtime check from syntax checks alone. Never claim to have listened to audio unless audio was actually reviewed. Do not replace a user's voice with unrelated narration.
