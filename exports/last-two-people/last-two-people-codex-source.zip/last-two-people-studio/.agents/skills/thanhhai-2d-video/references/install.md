# Codex installation
The studio is the repository root. Do not search for a Claude plugin.

1. `npm ci`
2. `python -m venv .venv`, then `.venv/bin/pip install -r requirements.txt`.
3. Use `CHROMIUM_PATH=/usr/bin/chromium` or install Chromium with Playwright.
4. `python tools/verify_kit.py` verifies the converted package.
5. `node render.mjs --project examples/reaction-time --sheet --scale 0.3`.
6. For transcription only, install requirements-whisper.txt. No model download is required for SRT input.

Read README.md and TEST-RESULTS.md. Do not use doctor --install: its original platform installer is retained as upstream code, not the recommended Codex installer.
