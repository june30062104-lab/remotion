# Nếu chỉ còn hai người
Kịch bản: bản tiếng Việt đã biên tập trong cuộc trò chuyện, không thêm hoặc bỏ lời kể.
Phong cách: người que điện ảnh, palette Dusk với bối cảnh sáng lạnh, nét viền sáng, cửa sổ và ánh đèn làm điểm sáng, bụi nhẹ, camera chậm. Không dùng ảnh ghép.
Nhân vật A: áo hoodie cam, tóc đuôi ngựa, từ ngái ngủ đến bối rối, biểu cảm lo lắng hài nhẹ. Nhân vật B: áo hoodie xanh, tóc nhọn, giật mình rồi nhún vai. Hướng A nhìn phải/B nhìn trái giữ nhất quán.
Bối cảnh: phòng ngủ sáng thứ Hai, phố trống và đường phố 3D, không gian sơ đồ nền xanh.
Nhịp: bí ẩn ở đầu, hài nhẹ khi gặp nhau, rồi đồ họa dân số và câu hỏi mở. Chỉ nhân vật nói thoại mới có chuyển động miệng.
Âm thanh: không dùng ambience xe/còi/khoan vì kịch bản mô tả sự vắng lặng; chỉ roomtone/gió rất nhẹ, nhạc mystery/playful/tension và SFX chuyển cảnh.
