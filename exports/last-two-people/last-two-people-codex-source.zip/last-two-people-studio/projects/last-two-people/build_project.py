from pathlib import Path
import json,math,subprocess,wave
import numpy as np
P=Path(__file__).resolve().parent
lines=json.loads((P/'input/lines.json').read_text());assets=P/'input/voice-assets'
provenance=json.loads((assets/'provenance.json').read_text()) if assets.exists() else {'engine':'pending','timing':'provisional'}
splits={'wake':('wake','wake_detail',.56),'drill':('drill','drill_detail',.58),'vanish':('vanish','empty3d',.48),'burden':('burden','burden_detail',.55),'population':('population','population_detail',.55),'math':('math','math_end',.64)}
shots=[];words=[];cues=[];offset=.4;audios=[np.zeros((round(offset*48000),2),np.float32)]
sfx={'wake':'tick','wake_detail':'swish','street':'wind','alarm':'tick','drill':'tick','drill_detail':'blip','vanish':'freeze','empty3d':'whoosh','almost':'ding','question':'swish','answer':'pop','names':'pop','burden':'impact','burden_detail':'whoosh','forty':'counter','pressure':'heartbeat','begin':'blip','population':'whoosh','population_detail':'counter','good':'shimmer','bad':'stinger','math':'glitch','math_end':'whoosh'}
for n,line in enumerate(lines):
 mp=assets/f'{n:02d}.mp3'
 if mp.exists():
  raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(mp),'-f','f32le','-ac','2','-ar','48000','-'])
  audio=np.frombuffer(raw,dtype=np.float32).reshape(-1,2).copy();duration=len(audio)/48000
  audios.append(audio);audios.append(np.zeros((round(line['pause']*48000),2),np.float32))
  local=json.loads((assets/f'{n:02d}.words.json').read_text())
 else:
  duration=max(1.3,len(line['text'].split())/3.4);local=[]
 if not local:
  toks=line['text'].split();weights=[len(w)+2 for w in toks];total=sum(weights);pos=.08
  for word,weight in zip(toks,weights):
   span=(duration-.22)*weight/total;local.append({'word':word,'start':pos,'end':pos+span*.94});pos+=span
 for w in local:words.append({'word':w['word'],'segment':n,'start':round(offset+w['start'],3),'end':round(offset+w['end'],3)})
 cues.append({'start':offset,'end':offset+duration,'text':line['text']})
 end=offset+duration+line['pause'];start=shots[-1]['end'] if shots else 0
 modes=splits.get(line['scene'])
 ranges=[(line['scene'],start,end)] if not modes else [(modes[0],start,offset+duration*modes[2]),(modes[1],offset+duration*modes[2],end)]
 for mode,a,b in ranges:
  trans='cut'
  if mode in ['empty3d','population','begin']:trans='dip'
  if mode in ['vanish']:trans='flash'
  if mode in ['almost','math_end']:trans='fade'
  cue={'at':.08,'name':sfx[mode],'gain':-18 if mode in ['wake','street','alarm','drill'] else -13}
  shot={'id':mode,'start':round(a,4),'end':round(b,4),'line':line['text'],'scene':mode,'in':{'type':trans,'dur':.22},'bars':'wide','sfx':[cue]}
  if mode in ['wake','wake_detail','drill']:shot['amb']={'name':'roomtone','gain':-32}
  elif mode in ['street','alarm','almost','question','names']:shot['amb']={'name':'wind','gain':-32}
  shots.append(shot)
 offset=end
# Align visual duration to a whole frame; pad sound to match.
frames=math.ceil(offset*24);duration=frames/24
shots[-1]['end']=duration
cfg={'title':'Neu-chi-con-hai-nguoi','lang':'vi','aspect':'16:9','resolution':'1080p','fps':24,'style':'dusk','voiceover':'input/voice.wav','script':'input/script.srt','duration':duration,'captions':True,'captionStyle':{'y':978,'size':46,'max':5},'bars':'wide','fadeIn':.35,'fadeOut':.7,'music':{'enabled':True,'gainDb':-23,'seed':24},'sfx':{'enabled':True,'gainDb':-9},'loudness':-16}
(P/'config.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
music=[{'start':0,'end':shots[8]['start'],'mood':'mystery','intensity':.35},{'start':shots[8]['start'],'end':next(s['start'] for s in shots if s['id']=='begin'),'mood':'playful','intensity':.22},{'start':next(s['start'] for s in shots if s['id']=='begin'),'end':duration,'mood':'tension','intensity':.35}]
(P/'story/shots.json').write_text(json.dumps({'duration':duration,'shots':shots,'music':music},ensure_ascii=False,indent=2))
(P/'timeline/words.json').write_text(json.dumps({'words':words,'source':provenance},ensure_ascii=False,indent=2))
(P/'timeline/sentences.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2))
def ts(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{s:02},{ms:03}'
(P/'input/script.srt').write_text('\n\n'.join(f'{n+1}\n{ts(c["start"])} --> {ts(c["end"])}\n{c["text"]}' for n,c in enumerate(cues))+'\n')
if assets.exists():
 import scipy.io.wavfile
 sound=np.concatenate(audios);n=round(duration*48000);sound=np.pad(sound,((0,max(0,n-len(sound))),(0,0)))[:n];scipy.io.wavfile.write(P/'input/voice.wav',48000,sound)
(P/'story/bible.md').write_text('''# Nếu chỉ còn hai người
Kịch bản: bản tiếng Việt đã biên tập trong cuộc trò chuyện, không thêm hoặc bỏ lời kể.
Phong cách: người que điện ảnh, palette Dusk với bối cảnh sáng lạnh, nét viền sáng, cửa sổ và ánh đèn làm điểm sáng, bụi nhẹ, camera chậm. Không dùng ảnh ghép.
Nhân vật A: áo hoodie cam, tóc đuôi ngựa, từ ngái ngủ đến bối rối, biểu cảm lo lắng hài nhẹ. Nhân vật B: áo hoodie xanh, tóc nhọn, giật mình rồi nhún vai. Hướng A nhìn phải/B nhìn trái giữ nhất quán.
Bối cảnh: phòng ngủ sáng thứ Hai, phố trống và đường phố 3D, không gian sơ đồ nền xanh.
Nhịp: bí ẩn ở đầu, hài nhẹ khi gặp nhau, rồi đồ họa dân số và câu hỏi mở. Chỉ nhân vật nói thoại mới có chuyển động miệng.
Âm thanh: không dùng ambience xe/còi/khoan vì kịch bản mô tả sự vắng lặng; chỉ roomtone/gió rất nhẹ, nhạc mystery/playful/tension và SFX chuyển cảnh.
''')
print(json.dumps({'duration':duration,'frames':frames,'shots':len(shots),'voice':provenance}))
