export const A={top:'hoodie',color:'#d76b46',head:'ponytail'};
export const B={top:'hoodie',color:'#4c83a4',head:'spiky'};
