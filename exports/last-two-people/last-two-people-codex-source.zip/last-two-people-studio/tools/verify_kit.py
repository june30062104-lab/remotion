"""Verify the converted source against conversion-manifest.json (not a signature)."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'conversion-manifest.json').read_text())
bad=[]
for rel,want in manifest['sha256'].items():
 p=root/rel
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=want:bad.append(rel)
if bad:raise SystemExit('Changed/missing: '+', '.join(bad))
print(f"{len(manifest['sha256'])}/{len(manifest['sha256'])} converted files verified")
