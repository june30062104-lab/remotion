"""Validate an exported MP4: streams, duration, dimensions and full decode."""
import argparse,json,subprocess
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('video');ap.add_argument('--duration',type=float,required=True);ap.add_argument('--width',type=int);ap.add_argument('--height',type=int);ap.add_argument('--out');a=ap.parse_args()
p=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',a.video]))
v=next((s for s in p['streams'] if s['codec_type']=='video'),None);au=next((s for s in p['streams'] if s['codec_type']=='audio'),None)
if not v or not au: raise SystemExit('FAIL: missing video/audio stream')
if abs(float(p['format']['duration'])-a.duration)>.15: raise SystemExit('FAIL: duration differs')
if a.width and v['width']!=a.width: raise SystemExit('FAIL: width differs')
if a.height and v['height']!=a.height: raise SystemExit('FAIL: height differs')
subprocess.run(['ffmpeg','-v','error','-xerror','-i',a.video,'-map','0:v:0','-map','0:a:0','-f','null','-'],check=True)
result={'status':'passed','duration':float(p['format']['duration']),'width':v['width'],'height':v['height'],'fps':v['avg_frame_rate'],'video_codec':v['codec_name'],'audio_codec':au['codec_name'],'full_decode':'passed','bytes':Path(a.video).stat().st_size}
if a.out: Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
