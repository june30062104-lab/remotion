# Thanh Hai 2D Studio for Codex

Use `.agents/skills/thanhhai-2d-video/SKILL.md` for video tasks. This project adapts the user-supplied Thanh Hai Learn AI plugin v0.2.0; retain its attribution. No Claude slash commands are required. Do not install packages globally; use a Python venv. Keep input narration intact. Ask only for genuinely missing requirements. Review stills before long renders. Use `CHROMIUM_PATH=/usr/bin/chromium` when available. Validate duration, stream presence and complete decoding before delivery. Never treat script claims as verified facts.

`node render.mjs --project examples/reaction-time --sheet --scale 0.3` is a visual self-test without voice. The original example does not include the referenced voice file.

Do not run the original checksum verifier after edits as if it validated the converted kit. `tools/verify_upstream.py` is retained only for upstream provenance. Run `tools/verify_kit.py` against `conversion-manifest.json` for the converted files.
