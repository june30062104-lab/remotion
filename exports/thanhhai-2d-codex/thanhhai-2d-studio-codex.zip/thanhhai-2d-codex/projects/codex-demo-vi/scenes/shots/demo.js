import {E, S, registerShot, text, rr, circle, layer, linGrad, glow, prog, ease} from '/engine/core.js';
import {drawFigure, POSES, breathe} from '/engine/rig2d.js';
import {dust} from '/engine/fx2d.js';
const cast = {top:'suit',color:'#345476',color2:'#d5ac65'};
function room(g,t){
 g.fillStyle=linGrad(g,0,0,0,E.H,['#17182e','#392b3e']);g.fillRect(-E.W,-E.H,E.W*3,E.H*3);
 const cam={z:1.01+t*.005,x:Math.sin(t*.2)*14};
 layer(g,cam,.3,()=>{g.fillStyle=linGrad(g,0,150,0,760,['#514c78','#e5aa7c']);g.fillRect(140,145,1640,610);glow(g,1450,430,260,'#ffcb88',.4);
 for(let i=0;i<20;i++){const h=90+(i*71)%280;g.fillStyle='#24253c';g.fillRect(140+i*85,750-h,66,h);for(let j=0;j<4;j++){g.fillStyle='#c99365';g.fillRect(155+i*85,770-h+j*40,8,12);}}
 g.fillStyle='#252237';for(let x=140;x<1800;x+=410)g.fillRect(x,145,16,610);g.fillRect(140,440,1640,14);});
 g.fillStyle='#201b2b';g.fillRect(-100,780,2120,500);dust(g,t,{count:35,a:.23});return cam;
}
function plate(g,x,y,s=1){g.save();g.translate(x,y);g.scale(s,s);circle(g,0,0,92,'#ded4c4');circle(g,0,0,69,'#a78461');for(let i=0;i<5;i++)circle(g,-35+i*18,Math.sin(i)*22,15,['#e2ae5c','#8baf6e','#c56f4c'][i%3]);g.restore();}
registerShot('wealth',{draw(g,t){const cam=room(g,t);layer(g,cam,1,()=>{drawFigure(g,{x:590,y:835,s:2.15,outfit:cast,pose:breathe(POSES.explain,t),expr:'thinking',rim:{color:'#ffcf91',dir:[1,-1],w:5}});});
 text(g,'HÀNG TRĂM TỶ ĐÔ LA',1230,315,{size:58,color:'#ffe1a6'});
 const p=ease.out(prog(t,.3,1.6));for(let i=0;i<5;i++){rr(g,970+i*100,740-(i+1)*55*p,70,(i+1)*55*p+2,8);g.fillStyle='#d6ac69';g.fill();}
 text(g,'KHỐI TÀI SẢN',1200,815,{size:31,font:'Nunito',weight:900,color:'#e5d9ca'});
}});
registerShot('choices',{draw(g,t){room(g,t);layer(g,{z:1+t*.007},1,()=>{drawFigure(g,{x:400,y:845,s:2,outfit:cast,pose:breathe(POSES.point,t),expr:'happy',rim:{color:'#ffd395',dir:[1,-1]}});});
 const labels=['MÓN ĂN','ĐẦU BẾP RIÊNG','NHÀ HÀNG'];for(let i=0;i<3;i++){const p=ease.out(prog(t,i*.18,.6+i*.18));g.save();g.globalAlpha=p;const x=800+i*335;rr(g,x-135,340+(1-p)*30,280,350,26);g.fillStyle='#302b44';g.fill();plate(g,x,470,.73);text(g,labels[i],x,625,{size:28,color:'#ffe1ad',font:'Nunito',weight:900});g.restore();}
}});
registerShot('breakfast',{draw(g,t){room(g,t);layer(g,{z:1.03+t*.006,x:10*t},1,()=>{g.fillStyle='#312d42';g.fillRect(570,650,30,210);g.fillRect(570,850,155,25);g.fillRect(580,875,20,110);g.fillRect(700,875,20,110);drawFigure(g,{x:620,y:850,s:2.2,outfit:cast,pose:breathe(POSES.sit,t),expr:'smile',rim:{color:'#ffd395',dir:[1,-1]}});
 g.fillStyle='#3d2934';g.fillRect(760,730,860,38);g.fillRect(820,768,30,220);g.fillRect(1540,768,30,220);plate(g,1110,704,.78);
 g.fillStyle='#eee0c8';rr(g,1350,620,54,85,12);g.fill();g.strokeStyle='#eee0c8';g.lineWidth=9;g.beginPath();g.arc(1410,655,24,-1.5,1.5);g.stroke();});
 text(g,'BỮA SÁNG TẠI NHÀ HÀNG',1120,275,{size:52,color:'#ffe1a6'});
}});
